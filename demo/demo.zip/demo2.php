<?php


abstract class Validator
{
    public $rules = [];
    public $errors = [];

    public function validate($number)
    {
        foreach($this->rules as $function) {
            $function($number);
        }
        return $this->errors;
    }

}


class ValidatorTruc extends Validator
{



    public function __construct()
    {
        $this->rules = [
            '>0' => function($number) {
                if($number <= 0 ) {
                    $this->errors['>0'] = "Le nombre doit être supérieur à 0";
                    return false;
                }
                return true;
            },
            'check2' => function($number) {
                if($number === 2 ) {
                    $this->errors['check2'] = "Le nombre 2 est interdit";
                    return false;
                }
                return true;
            },
            'checkMax' => function($number) {
                if($number > 1000 ) {
                    $this->errors['checkMax'] = "Le nombre doit être inférieur à 1000";
                    return false;
                }
                return true;
            },
            'isModulo3' => function($number) {
                if($number % 3 === 0 ) {
                    $this->errors['isModulo3'] = "Le nombre ne doit pas être un multiple de trois";
                    return false;
                }
                return true;
            },
            'isModulo5' => function($number) {
                if($number % 5 === 0 ) {
                    $this->errors['isModulo5'] = "Le nombre ne doit pas être un multiple de cinq";
                    return false;
                }
                return true;
            },
        ];
    }
}


class ValidatorType extends Validator
{
    public $rules = [];
    public $errors = [];


    public function __construct()
    {
        $this->rules = [
            'checkType' => function($number) {
                if(!is_int($number)) {
                    $this->errors['>checkType'] = "Le nombre doit n'est pas du type \"int \"";
                    return false;
                }
                return true;
            },
            '%4' => function($number) {

                if(!($number % 4)) {
                    $this->errors['%4'] = "Le nombre doit ne pas pas être un multiple de 4";
                    return false;
                }
                return true;
            },
        ];
    }
}



$validators = [
    'ValidatorType',
    'ValidatorTruc'
];


$number = 60;
$errors = [];
foreach($validators as $validatorName) {
    $validator = new $validatorName();
    $validatorErrors = $validator->validate($number);
    if(!empty($validatorErrors)) {
        $errors[$validatorName] = $validatorErrors;
        // break; // sortir de la boucle
    }
}


if(empty($errors)) {
    echo "succès";
}
else {
    echo "échec";
    echo '<div style="border: solid 2px #F00">';
        echo '<div style="; background-color:#CCC">@'.__FILE__.' : '.__LINE__.'</div>';
        echo '<pre style="background-color: rgba(255,255,255, 0.8);">';
        print_r($errors);
        echo '</pre>';
    echo '</div>';
}

