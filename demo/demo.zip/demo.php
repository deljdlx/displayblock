<?php


function sayHello($name, $formater = null)
{
    if(!$formater) {
        return 'hello ' . $name;
    }
    else {
        return $formater($name);
    }
}


$blagueDuJour = "La brute force, si ça ne marche pas, c'est qu'elle n'est pas pas assez utllisée";

$sayHello = [
    'fr-base' => function($name) use ($blagueDuJour) {
        return 'Bonjour ' . $name . '<p>' . $blagueDuJour . '</p>';
    },
    'fr-soutenu' => function($name) use ($blagueDuJour) {
        return 'Bien le bonjour cher ' . $name . '<p>' . $blagueDuJour . '</p>';
    }
];


echo sayHello('Bill');
echo '<hr />';
echo sayHello('Bill', $sayHello['fr-soutenu']);


echo '<hr />';




$numberrRules = [
    'check2' => function($number, &$errors = null) {
        if($number === 2 ) {
            $errors['check2'] = "Le nombre 2 est interdit";
            return false;
        }
        return true;
    },
    'checkMax' => function($number, &$errors = null) {
        if($number > 1000 ) {
            $errors['checkMax'] = "Le nombre doit être inférieur à 1000";
            return false;
        }
        return true;
    },
    'isModulo3' => function($number, &$errors = null) {
        if($number % 3 === 0 ) {
            $errors['isModulo3'] = "Le nombre ne doit pas être un multiple de trois";
            return false;
        }
        return true;
    },
    'isModulo5' => function($number, &$errors = null) {
        if($number % 5 === 0 ) {
            $errors['isModulo5'] = "Le nombre ne doit pas être un multiple de cinq";
            return false;
        }
        return true;
    },
];
























function isNumberValid($number, $rules = [])
{
    $errors = [];

    foreach($rules as $index => $function) {
        $function($number, $errors);
    }

    return $errors;
}



$errors = isNumberValid(15, $numberrRules);

if(empty($errors)) {
    echo "succès";
}
else {
    echo "échec";
    echo '<div style="border: solid 2px #F00">';
        echo '<div style="; background-color:#CCC">@'.__FILE__.' : '.__LINE__.'</div>';
        echo '<pre style="background-color: rgba(255,255,255, 0.8);">';
        print_r($errors);
        echo '</pre>';
    echo '</div>';
}

















