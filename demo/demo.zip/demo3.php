<?php


abstract class Validator
{
    public $rules = [];
    public $errors = [];

    public function validate($number)
    {
        //$number = $number->getNumber();
        foreach($this->rules as $function) {
            $function($number);
        }
        return $this->errors;
    }

}


class ValidatorTruc extends Validator
{



    public function __construct()
    {
        $prefix = __CLASS__;
        // __NAMESPACE__
        $this->rules = [
            '>0' => function($number) use($prefix){
                $numberRaw = $number->getNumber();
                if($numberRaw <= 0 ) {
                    $this->errors['>0'] = '[' . $prefix . ']' . " Le nombre doit être supérieur à 0";
                    return false;
                }
                return true;
            },
            'check2' => function($number) {
                $numberRaw = $number->getNumber();
                if($numberRaw === 2 ) {
                    $this->errors['check2'] = "Le nombre 2 est interdit";
                    return false;
                }
                return true;
            },
            'checkMax' => function($number) {
                $numberRaw = $number->getNumber();
                if($numberRaw > 1000 ) {
                    $this->errors['checkMax'] = "Le nombre doit être inférieur à 1000";
                    return false;
                }
                return true;
            },
            'isModulo3' => function($number) {
                $numberRaw = $number->getNumber();
                if($numberRaw % 3 === 0 ) {
                    $this->errors['isModulo3'] = "Le nombre ne doit pas être un multiple de trois";
                    return false;
                }
                return true;
            },
            'isModulo5' => function($number) {
                $numberRaw = $number->getNumber();
                if($numberRaw % 5 === 0 ) {
                    $this->errors['isModulo5'] = "Le nombre ne doit pas être un multiple de cinq";
                    return false;
                }
                return true;
            },
        ];
    }
}


class ValidatorType extends Validator
{
    public $rules = [];
    public $errors = [];


    public function __construct()
    {
        $this->rules = [
            'checkType' => function($number) {
                $numberRaw = $number->getNumber();
                if(!is_int($numberRaw)) {
                    $this->errors['>checkType'] = "Le nombre doit n'est pas du type \"int \"";
                    return false;
                }
                return true;
            },
            '%4' => function($number) {
                $numberRaw = $number->getNumber();
                if(!($numberRaw % 4)) {
                    $this->errors['%4'] = "Le nombre doit ne pas pas être un multiple de 4";
                    return false;
                }
                return true;
            },
            'log' => function($number) {

                $💩 = 'poop';
                $number->addToLog($💩, '💩');
                return true;
            },
        ];
    }
}

class Number
{
    protected $number;
    protected $isDecimal = false;

    protected $log = [];

    public function __construct($number)
    {
        $this->number = $number;
        if(floor($number) != $number) {
            $this->isDecimal = true;
        }
    }

    /**
     * Get the value of number
     */
    public function getNumber()
    {
        return $this->number;
    }

    public function addToLog($message, $index = null)
    {
        if(!$index) {
            $this->log[] = $message;
        }
        else {
            $this->log[$index] = $message;
        }

        return $this;
    }

    public function getLog()
    {
        return $this->log;
    }
}



$validators = [
    'ValidatorType',
    'ValidatorTruc'
];


$number = new Number(0);
$errors = [];
foreach($validators as $validatorName) {
    $validator = new $validatorName();
    $validatorErrors = $validator->validate($number);
    if(!empty($validatorErrors)) {
        $errors[$validatorName] = $validatorErrors;
        // break; // sortir de la boucle
    }
}


if(empty($errors)) {
    echo "succès";
}
else {
    echo "échec";
    echo '<div style="border: solid 2px #F00">';
        echo '<div style="; background-color:#CCC">@'.__FILE__.' : '.__LINE__.'</div>';
        echo '<pre style="background-color: rgba(255,255,255, 0.8);">';
        print_r($errors);
        echo '</pre>';
    echo '</div>';
}

echo '<div style="border: solid 2px #F00">';
    echo '<div style="; background-color:#CCC">@'.__FILE__.' : '.__LINE__.'</div>';
    echo '<pre style="background-color: rgba(255,255,255, 0.8);">';
    print_r($number);
    echo '</pre>';
echo '</div>';

